"use client";

import type React from "react";

import { useState, useEffect } from "react";
import { X, Upload, UserIcon, Shield, Settings, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import type { User } from "../types/user-management";
import { mockUserRoles, mockPermissionModules } from "../types/user-management";

interface AddEditUserModalProps {
  isOpen: boolean;
  onClose: () => void;
  user?: User | null;
  onSave: (userData: Partial<User>) => void;
  onChangesDetected: (hasChanges: boolean) => void;
}

export function AddEditUserModal({
  isOpen,
  onClose,
  user,
  onSave,
  onChangesDetected,
}: AddEditUserModalProps) {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "TempPassword123!", // Default password for new users
    // phone: "",
    // department: "",
    roleId: "",
    status: "active" as const,
    avatar: "",
    // bio: "",
    twoFactorEnabled: false,
    emailNotifications: true,
    permissions: {} as Record<string, Record<string, boolean>>,
  });

  const [activeTab, setActiveTab] = useState("basic");
  const [avatarPreview, setAvatarPreview] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string>("");
  const [showPassword, setShowPassword] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    if (user) {
      // Editing existing user
      setIsEditing(true);
      setFormData({
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        password: "", // Empty password for existing users (won't be changed unless specified)
        // phone: user.phone || "",
        // department: user.department || "",
        roleId: user.role.id,
        status: user.status,
        avatar: user.avatar || "",
        // bio: "",
        twoFactorEnabled: user.twoFactorEnabled,
        emailNotifications: true,
        permissions: {},
      });
      setAvatarPreview(user.avatar || "");
    } else {
      // Creating new user
      setIsEditing(false);
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        password: "TempPassword123!",
        // phone: "",
        // department: "",
        roleId: "",
        status: "active",
        avatar: "",
        // bio: "",
        twoFactorEnabled: false,
        emailNotifications: true,
        permissions: {},
      });
      setAvatarPreview("");
    }
    setError("");
  }, [user, isOpen]);

  const handleSave = async () => {
    if (!formData.firstName || !formData.lastName || !formData.email || !formData.roleId) {
      setError("Please fill in all required fields");
      return;
    }

    setIsLoading(true);
    setError("");

    try {
      if (isEditing && user) {
        // Edit existing user
        const response = await fetch(`http://localhost:8000/api/v1/auth/${user.id}/update-user/`, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email: formData.email,
            firstname: formData.firstName,
            lastname: formData.lastName,
            role: formData.roleId,
            disabled: formData.status === "inactive",
            // phone: formData.phone,
            // department: formData.department,
          }),
        });

        const result = await response.json();

        if (result.success) {
          // Convert backend response to frontend user format
          const updatedUser: User = {
            id: result.user.id,
            firstName: result.user.firstname || result.user.firstName,
            lastName: result.user.lastname || result.user.lastName,
            email: result.user.email,
            // phone: result.user.phone || "",
            avatar: result.user.avatar || "",
            role: mockUserRoles.find(role => role.id === result.user.role) || mockUserRoles[2],
            status: result.user.disabled ? "inactive" : "active",
            // department: result.user.department || "",
            lastLogin: result.user.last_login_formatted || user.lastLogin,
            createdAt: result.user.created_at_formatted || user.createdAt,
            isEmailVerified: result.user.email_verified || user.isEmailVerified,
            twoFactorEnabled: result.user.two_factor_enabled || user.twoFactorEnabled,
            permissions: user.permissions,
          };

          onSave(updatedUser);
          onChangesDetected(true);
          onClose();
        } else {
          setError(result.error || "Failed to update user");
        }
      } else {
        // Create new user
        const response = await fetch("http://localhost:8000/api/v1/auth/create-user/", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email: formData.email,
            password: formData.password,
            firstname: formData.firstName,
            lastname: formData.lastName,
            role: formData.roleId,
            // Note: department and phone are commented out in backend as requested
          }),
        });

        const result = await response.json();

        if (result.success) {
          // Convert backend response to frontend user format
          const newUser: User = {
            id: result.user.id,
            firstName: result.user.firstname || result.user.firstName,
            lastName: result.user.lastname || result.user.lastName,
            email: result.user.email,
            // phone: result.user.phone || "",
            avatar: result.user.avatar || "",
            role: mockUserRoles.find(role => role.id === result.user.role) || mockUserRoles[2],
            status: result.user.disabled ? "inactive" : "active",
            // department: result.user.department || "",
            lastLogin: result.user.last_login_formatted || "Never",
            createdAt: result.user.created_at_formatted || new Date().toISOString(),
            isEmailVerified: result.user.email_verified || false,
            twoFactorEnabled: result.user.two_factor_enabled || false,
            permissions: [],
          };

          onSave(newUser);
          onChangesDetected(true);
          onClose();
        } else {
          setError(result.error || "Failed to create user");
        }
      }
    } catch (err) {
      console.error("Error saving user:", err);
      setError(isEditing ? "Failed to update user. Please try again." : "Failed to create user. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleAvatarUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setAvatarPreview(result);
        setFormData((prev) => ({ ...prev, avatar: result }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePermissionChange = (
    moduleId: string,
    permission: string,
    granted: boolean
  ) => {
    setFormData((prev) => ({
      ...prev,
      permissions: {
        ...prev.permissions,
        [moduleId]: {
          ...prev.permissions[moduleId],
          [permission]: granted,
        },
      },
    }));
  };

  const selectedRole = mockUserRoles.find(
    (role) => role.id === formData.roleId
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserIcon className="h-5 w-5" />
            {isEditing ? "Edit User" : "Add New User"}
          </DialogTitle>
          <Button
            variant="ghost"
            size="sm"
            className="absolute right-4 top-4"
            onClick={onClose}
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md">
            {error}
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="basic">Basic Info</TabsTrigger>
            <TabsTrigger value="permissions">Permissions</TabsTrigger>
            <TabsTrigger value="preferences">Preferences</TabsTrigger>
          </TabsList>

          <TabsContent value="basic" className="space-y-6 mt-6">
            {/* Profile Picture */}
            <div className="flex items-center space-x-6">
              <div className="relative">
                <Avatar className="h-24 w-24">
                  <AvatarImage
                    src={avatarPreview || "/placeholder.svg"}
                    alt="Profile"
                  />
                  <AvatarFallback className="text-lg">
                    {formData.firstName.charAt(0)}
                    {formData.lastName.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <label className="absolute bottom-0 right-0 bg-blue-600 text-white p-2 rounded-full cursor-pointer hover:bg-blue-700">
                  <Upload className="h-3 w-3" />
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarUpload}
                    className="hidden"
                  />
                </label>
              </div>
              <div>
                <h3 className="text-lg font-medium">Profile Picture</h3>
                <p className="text-sm text-gray-600">
                  Upload a profile picture for this user
                </p>
              </div>
            </div>

            {/* Basic Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="firstName">First Name *</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      firstName: e.target.value,
                    }))
                  }
                  placeholder="Enter first name"
                />
              </div>

              <div>
                <Label htmlFor="lastName">Last Name *</Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      lastName: e.target.value,
                    }))
                  }
                  placeholder="Enter last name"
                />
              </div>

              <div>
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, email: e.target.value }))
                  }
                  placeholder="Enter email address"
                />
              </div>

              {!isEditing && (
                <div>
                  <Label htmlFor="password">Password *</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={formData.password}
                      onChange={(e) =>
                        setFormData((prev) => ({ ...prev, password: e.target.value }))
                      }
                      placeholder="Enter password"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">
                    Default password: TempPassword123!
                  </p>
                </div>
              )}

              <div>
                <Label htmlFor="role">Role *</Label>
                <Select
                  value={formData.roleId}
                  onValueChange={(value) =>
                    setFormData((prev) => ({ ...prev, roleId: value }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    {mockUserRoles.map((role) => (
                      <SelectItem key={role.id} value={role.id}>
                        <div className="flex items-center space-x-2">
                          <div
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: role.color }}
                          />
                          <span>{role.name}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {selectedRole && (
                  <p className="text-sm text-gray-600 mt-1">
                    {selectedRole.description}
                  </p>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="permissions" className="space-y-6 mt-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium">
                    Role-Based Permissions
                  </h3>
                  <p className="text-sm text-gray-600">
                    Configure specific permissions for this user
                  </p>
                </div>
                {selectedRole && (
                  <Badge
                    style={{
                      backgroundColor: `${selectedRole.color}20`,
                      color: selectedRole.color,
                    }}
                  >
                    {selectedRole.name}
                  </Badge>
                )}
              </div>

              {/* Permission Matrix */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Permission Matrix
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {mockPermissionModules.map((module) => (
                      <div key={module.id} className="space-y-3">
                        <h4 className="font-medium text-gray-900">
                          {module.name}
                        </h4>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          {module.permissions.map((permission) => (
                            <div
                              key={permission}
                              className="flex items-center space-x-2"
                            >
                              <Checkbox
                                id={`${module.id}-${permission}`}
                                checked={
                                  formData.permissions[module.id]?.[
                                    permission
                                  ] || false
                                }
                                onCheckedChange={(checked) =>
                                  handlePermissionChange(
                                    module.id,
                                    permission,
                                    checked as boolean
                                  )
                                }
                              />
                              <Label
                                htmlFor={`${module.id}-${permission}`}
                                className="text-sm capitalize"
                              >
                                {permission}
                              </Label>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="preferences" className="space-y-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  User Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Security Settings */}
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900">
                    Security Settings
                  </h4>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Two-Factor Authentication</Label>
                      <p className="text-sm text-gray-600">
                        Require 2FA for this user
                      </p>
                    </div>
                    <Switch
                      checked={formData.twoFactorEnabled}
                      onCheckedChange={(checked) =>
                        setFormData((prev) => ({
                          ...prev,
                          twoFactorEnabled: checked,
                        }))
                      }
                    />
                  </div>
                </div>

                {/* Notification Settings */}
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900">
                    Notification Settings
                  </h4>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Email Notifications</Label>
                      <p className="text-sm text-gray-600">
                        Send email notifications to this user
                      </p>
                    </div>
                    <Switch
                      checked={formData.emailNotifications}
                      onCheckedChange={(checked) =>
                        setFormData((prev) => ({
                          ...prev,
                          emailNotifications: checked,
                        }))
                      }
                    />
                  </div>
                </div>

                {/* Account Status */}
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900">Account Status</h4>

                  <div>
                    <Label>Status</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value: "active" | "inactive") =>
                        setFormData((prev) => ({ ...prev, status: value }))
                      }
                    >
                      <SelectTrigger className="w-48">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="inactive">Inactive</SelectItem>
                      </SelectContent>
                </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Footer Actions */}
        <div className="flex justify-end space-x-3 pt-6 border-t">
          <Button variant="outline" onClick={onClose} disabled={isLoading}>
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={
              isLoading ||
              !formData.firstName ||
              !formData.lastName ||
              !formData.email ||
              (!isEditing && !formData.password) || // Password only required for new users
              !formData.roleId
            }
            className="bg-blue-600 hover:bg-blue-700"
          >
            {isLoading ? (isEditing ? "Updating..." : "Creating...") : isEditing ? "Update User" : "Create User"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}